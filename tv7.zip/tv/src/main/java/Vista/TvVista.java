
package Vista;
import javax.swing.ImageIcon;
import Modelo.Modelo;
import java.awt.Color;
import javax.swing.DefaultListModel; 
import java.util.ArrayList;
/**
 *
 * @author laucami
 * @author roggonz
 */
public class TvVista extends javax.swing.JFrame {
    
    private Modelo modelo;
    private Controlador controlador;
   
    
    /**
     * Creates new form TvVista
     */
    public TvVista() {
        initComponents();
        modelo=new Modelo();
        controlador=new Controlador(this,modelo);
        listaFavoritos.setModel(modelo.getListaFavs());
        refrescar();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        ordenar = new javax.swing.JToggleButton();
        favoritos = new javax.swing.JToggleButton();
        editar = new javax.swing.JToggleButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        pantalla = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        iconCanal1 = new javax.swing.JLabel();
        iconCanal2 = new javax.swing.JLabel();
        iconCanal3 = new javax.swing.JLabel();
        iconCanal4 = new javax.swing.JLabel();
        iconCanal5 = new javax.swing.JLabel();
        iconCanal6 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        canal1 = new javax.swing.JTextField();
        canal2 = new javax.swing.JTextField();
        canal3 = new javax.swing.JTextField();
        canal4 = new javax.swing.JTextField();
        canal5 = new javax.swing.JTextField();
        canal6 = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        canal = new javax.swing.JLabel();
        activado = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        nombreCanal = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaFavoritos = new javax.swing.JList<>();
        jPanel11 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        borrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray, 15));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(java.awt.Color.darkGray);

        ordenar.setBackground(new java.awt.Color(81, 120, 195));
        ordenar.setFont(new java.awt.Font("Ubuntu Mono", 1, 21)); // NOI18N
        ordenar.setText("Ordenar");
        ordenar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ordenarMouseClicked(evt);
            }
        });
        jPanel2.add(ordenar);

        favoritos.setBackground(new java.awt.Color(254, 95, 193));
        favoritos.setFont(new java.awt.Font("Ubuntu Mono", 1, 21)); // NOI18N
        favoritos.setText("Favoritos");
        favoritos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                favoritosMouseClicked(evt);
            }
        });
        jPanel2.add(favoritos);

        editar.setBackground(new java.awt.Color(55, 222, 34));
        editar.setFont(new java.awt.Font("Ubuntu Mono", 1, 21)); // NOI18N
        editar.setText("Editar");
        editar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editarMouseClicked(evt);
            }
        });
        jPanel2.add(editar);

        jPanel1.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel3.setLayout(new java.awt.GridLayout(2, 1));

        jPanel4.setLayout(new java.awt.GridLayout(1, 3, 30, 0));

        pantalla.setBackground(java.awt.Color.black);
        pantalla.setForeground(new java.awt.Color(1, 1, 1));
        pantalla.setOpaque(true);
        jPanel4.add(pantalla);

        jPanel6.setLayout(new java.awt.BorderLayout());

        jPanel7.setLayout(new java.awt.GridLayout(6, 1));
        jPanel7.add(iconCanal1);
        jPanel7.add(iconCanal2);
        jPanel7.add(iconCanal3);
        jPanel7.add(iconCanal4);
        jPanel7.add(iconCanal5);
        jPanel7.add(iconCanal6);

        jPanel6.add(jPanel7, java.awt.BorderLayout.LINE_START);

        jPanel8.setLayout(new java.awt.GridLayout(6, 1));

        canal1.setEditable(false);
        canal1.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        canal1.setText("La 1");
        canal1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canal1MouseClicked(evt);
            }
        });
        jPanel8.add(canal1);

        canal2.setEditable(false);
        canal2.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        canal2.setText("La 2");
        canal2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canal2MouseClicked(evt);
            }
        });
        jPanel8.add(canal2);

        canal3.setEditable(false);
        canal3.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        canal3.setText("Antena 3");
        canal3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canal3MouseClicked(evt);
            }
        });
        jPanel8.add(canal3);

        canal4.setEditable(false);
        canal4.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        canal4.setText("Cuatro");
        canal4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canal4MouseClicked(evt);
            }
        });
        jPanel8.add(canal4);

        canal5.setEditable(false);
        canal5.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        canal5.setText("Telecinco");
        canal5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canal5MouseClicked(evt);
            }
        });
        jPanel8.add(canal5);

        canal6.setEditable(false);
        canal6.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        canal6.setText("La Sexta");
        canal6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canal6MouseClicked(evt);
            }
        });
        jPanel8.add(canal6);

        jPanel6.add(jPanel8, java.awt.BorderLayout.CENTER);

        jPanel4.add(jPanel6);

        jPanel3.add(jPanel4);

        jPanel5.setLayout(new java.awt.GridLayout(3, 1));

        jPanel9.setLayout(new java.awt.GridLayout(1, 3));

        canal.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        canal.setText("  Canal");
        jPanel9.add(canal);

        activado.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        activado.setSelected(true);
        activado.setText("Activado");
        activado.setEnabled(false);
        activado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                activadoMouseClicked(evt);
            }
        });
        jPanel9.add(activado);

        jLabel9.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        jLabel9.setText(" Favoritos");
        jPanel9.add(jLabel9);

        jPanel5.add(jPanel9);

        jPanel10.setLayout(new java.awt.GridLayout(1, 3, 5, 0));

        jLabel10.setFont(new java.awt.Font("Ubuntu Mono", 1, 20)); // NOI18N
        jLabel10.setText("         Nombre del canal");
        jPanel10.add(jLabel10);

        nombreCanal.setFont(new java.awt.Font("Ubuntu Mono", 1, 22)); // NOI18N
        nombreCanal.setEnabled(false);
        nombreCanal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nombreCanalKeyReleased(evt);
            }
        });
        jPanel10.add(nombreCanal);

        listaFavoritos.setFont(new java.awt.Font("Ubuntu Mono", 1, 18)); // NOI18N
        listaFavoritos.setEnabled(false);
        jScrollPane1.setViewportView(listaFavoritos);

        jPanel10.add(jScrollPane1);

        jPanel5.add(jPanel10);

        jPanel11.setLayout(new java.awt.GridLayout(1, 4));

        jPanel14.setBackground(java.awt.Color.darkGray);

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 288, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );

        jPanel11.add(jPanel14);

        jPanel12.setBackground(java.awt.Color.darkGray);
        jPanel11.add(jPanel12);

        jPanel13.setBackground(java.awt.Color.darkGray);

        borrar.setBackground(new java.awt.Color(254, 51, 34));
        borrar.setFont(new java.awt.Font("Ubuntu Mono", 1, 21)); // NOI18N
        borrar.setText("Borrar");
        borrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                borrarMouseClicked(evt);
            }
        });
        jPanel13.add(borrar);

        jPanel11.add(jPanel13);

        jPanel5.add(jPanel11);

        jPanel3.add(jPanel5);

        jPanel1.add(jPanel3, java.awt.BorderLayout.CENTER);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void canal1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_canal1MouseClicked
        controlador.procesarClickCanal1();
    }//GEN-LAST:event_canal1MouseClicked

    private void canal2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_canal2MouseClicked
        controlador.procesarClickCanal2();
    }//GEN-LAST:event_canal2MouseClicked

    private void canal3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_canal3MouseClicked
        controlador.procesarClickCanal3();
    }//GEN-LAST:event_canal3MouseClicked

    private void canal4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_canal4MouseClicked
        controlador.procesarClickCanal4();
    }//GEN-LAST:event_canal4MouseClicked

    private void canal5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_canal5MouseClicked
        controlador.procesarClickCanal5();
    }//GEN-LAST:event_canal5MouseClicked

    private void canal6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_canal6MouseClicked
        controlador.procesarClickCanal6();
    }//GEN-LAST:event_canal6MouseClicked

    private void borrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_borrarMouseClicked
        controlador.procesaClickBorrar();
    }//GEN-LAST:event_borrarMouseClicked

    private void ordenarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ordenarMouseClicked
        controlador.procesaClickOrdenar();
    }//GEN-LAST:event_ordenarMouseClicked

    private void favoritosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_favoritosMouseClicked
        controlador.procesaClickFavoritos();
    }//GEN-LAST:event_favoritosMouseClicked

    private void editarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarMouseClicked
        controlador.procesaClickEditar();
    }//GEN-LAST:event_editarMouseClicked

    private void activadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_activadoMouseClicked
        controlador.procesaClickActivado();
    }//GEN-LAST:event_activadoMouseClicked

    private void nombreCanalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreCanalKeyReleased
        controlador.procesaNombreCanalKeyRealeased();
    }//GEN-LAST:event_nombreCanalKeyReleased
    
    public boolean isOrdenarSelected(){
        return ordenar.isSelected();
    }
    
    public boolean isFavoritosSelected(){
        return favoritos.isSelected();
    }
    
    public boolean isEditarSelected(){
        return editar.isSelected();
    }
    
    public boolean isActivadoSelected(){
        return activado.isSelected();
    }
   
    public void setFavoritosSelected(boolean b){
        favoritos.setSelected(b);
    }
    
    public void setEditarSelected(boolean b){
        editar.setSelected(b);
    }
    
    public void setOrdenarSelected(boolean b){
        ordenar.setSelected(b);
    }
    
    public void setListaFavoritosEnabled(boolean b){
        listaFavoritos.setEnabled(b);
    }
    
    public void setActivadoEnabled(boolean b){
        activado.setEnabled(b);
    }
    
    public void setNombreCanalEnabled(boolean b){
        nombreCanal.setEnabled(b);
    }
    
    public void setCanalText(String text){
        canal.setText(text);
    }
    
    public void setNombreCanalText(String text){
        nombreCanal.setText(text);
    }
    
    public String getNombreCanalText(){
        return nombreCanal.getText();
    }
    
    public void setActivadoSelected(boolean s){
        activado.setSelected(s);
    }
    
    public void setPantallaIcon(ImageIcon s){
        pantalla.setIcon(s);
    }
    
    public int getListaFavoritosSelectedIndex(){
        return listaFavoritos.getSelectedIndex();
    }
    
    
    public void remarcarCanal(int numCanal){
        if(numCanal==1){canal1.setBackground(Color.red);}
        else if(numCanal==2){canal2.setBackground(Color.red);}
        else if(numCanal==3){canal3.setBackground(Color.red);}
        else if(numCanal==4){canal4.setBackground(Color.red);}
        else if(numCanal==5){canal5.setBackground(Color.red);}
        else if(numCanal==6){canal6.setBackground(Color.red);}
    }
    
    public void sinSeleccionar(){
        canal1.setBackground(Color.white);
        canal2.setBackground(Color.white);
        canal3.setBackground(Color.white);
        canal4.setBackground(Color.white);
        canal5.setBackground(Color.white);
        canal6.setBackground(Color.white);
    }
    
    public void refrescar(){
        iconCanal1.setIcon(modelo.getIconCanal(1));
        iconCanal2.setIcon(modelo.getIconCanal(2));
        iconCanal3.setIcon(modelo.getIconCanal(3));
        iconCanal4.setIcon(modelo.getIconCanal(4));
        iconCanal5.setIcon(modelo.getIconCanal(5));
        iconCanal6.setIcon(modelo.getIconCanal(6));
        
        canal1.setText(modelo.getCanal(1));
        canal2.setText(modelo.getCanal(2));
        canal3.setText(modelo.getCanal(3));
        canal4.setText(modelo.getCanal(4));
        canal5.setText(modelo.getCanal(5));
        canal6.setText(modelo.getCanal(6));
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox activado;
    private javax.swing.JButton borrar;
    private javax.swing.JLabel canal;
    private javax.swing.JTextField canal1;
    private javax.swing.JTextField canal2;
    private javax.swing.JTextField canal3;
    private javax.swing.JTextField canal4;
    private javax.swing.JTextField canal5;
    private javax.swing.JTextField canal6;
    private javax.swing.JToggleButton editar;
    private javax.swing.JToggleButton favoritos;
    private javax.swing.JLabel iconCanal1;
    private javax.swing.JLabel iconCanal2;
    private javax.swing.JLabel iconCanal3;
    private javax.swing.JLabel iconCanal4;
    private javax.swing.JLabel iconCanal5;
    private javax.swing.JLabel iconCanal6;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> listaFavoritos;
    private javax.swing.JTextField nombreCanal;
    private javax.swing.JToggleButton ordenar;
    private javax.swing.JButton pantalla;
    // End of variables declaration//GEN-END:variables

}

