
package Vista;

import Modelo.Modelo;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.DefaultListModel; 
import java.util.ArrayList;
/**
 *
 * @author laucami
 * @author roggonz
 * 
 */
public class Controlador {
    
    private TvVista vista;
    private Modelo modelo;

    public Controlador(TvVista v, Modelo m) {
        vista=v;
        modelo=m;
    }

          /////////////PULSAR EN CANALES ///////////////////
    
    public void procesarClickCanal1(){
        
        DefaultListModel lisFav=modelo.getListaFavs();
        int canSelecc=modelo.getCanalSeleccionado();
        ArrayList<Integer> canalesEnFavs=modelo.getCanalesEnFavoritos();
        
        if(vista.isOrdenarSelected()){//SI SE PULSO ORDENAR
            
            if(modelo.isCanalSeleccionado()){//se intercambian los canales de sitio
                String textoActual=modelo.getCanal(1);
                ImageIcon iconoActual=modelo.getIconCanal(1);
                boolean visionActual=modelo.getVisionCanal(1);
                
                //texto icono y visibilidad del canal1=texto icono y visibilidad del canal seleccionado
                modelo.setCanal(1,modelo.getCanal(canSelecc),modelo.getIconCanal(canSelecc));
                modelo.setVisionCanal(1, modelo.getVisionCanal(canSelecc));
                
                //texto icono y visibilidad del canal seleccionado=texto icono y visibilidad del canal 1
                modelo.setCanal(canSelecc,textoActual,iconoActual);
                modelo.setVisionCanal(canSelecc, visionActual);
                
                System.out.println("canalesEnFavs: "+canalesEnFavs.toArray());//////////
                
                //se intercambian posiciones en el vector de canales en la lista de favoritos
                if(canalesEnFavs.contains(1)){
                canalesEnFavs.set(canalesEnFavs.indexOf(1), -2);
                }
                if(canalesEnFavs.contains(canSelecc)){
                canalesEnFavs.set(canalesEnFavs.indexOf(canSelecc), 1);
                }
                if(canalesEnFavs.contains(-2)){
                canalesEnFavs.set(canalesEnFavs.indexOf(-2),canSelecc);
                }
                
                System.out.println("canalesEnFavs: "+canalesEnFavs.toArray());/////////////
                
                //actualizamos la lista en el modelo
                modelo.setCanalesEnFavoritos(canalesEnFavs); 
                
                //refrescamos para que los textos e iconos se coloquen en sus nuevas posiciones
                vista.refrescar();
                modelo.setIsCanalSeleccionado(false);
                vista.sinSeleccionar();
            }
           
            else{//se marca como canal seleccionado ya que no habia ninguno antes
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(1);
            vista.remarcarCanal(1); 
            }
            
        }
        
        else if(vista.isFavoritosSelected()){//SI SE PULSO FAVORITOS
          
            if(lisFav.contains(modelo.getCanal(1))==false){//se añade a favoritos si no esta
            lisFav.addElement(modelo.getCanal(1));
            canalesEnFavs.add(1); 
            
            modelo.setCanalesEnFavoritos(canalesEnFavs); //actualizamos listas
            modelo.setListaFavs(lisFav);
            }
        }
        
        else if(vista.isEditarSelected()){//SI SE PULSO EDITAR
            
            modelo.setIsCanalSeleccionado(true); //se marca como canal seleccionado
            modelo.setCanalSeleccionado(1);
            
            //datos del canal en zona de edicion 
            vista.setCanalText("  Canal: "+modelo.getCanal(1)); 
            vista.setNombreCanalText(modelo.getCanal(1));
            vista.setActivadoSelected(modelo.getVisionCanal(1));
        }
        
        else {//SI NINGUN BOTON (EDITAR,FAVORITOS,ORDENAR) ESTA ACTIVADO
            
            if(modelo.getVisionCanal(1)){//si el canal tiene vision activada se muestra por pantalla
            vista.setPantallaIcon(modelo.getIconCanal(1)); 
            }
            else{//si el canal tiene vision desactivada no se mostrara nada por pantalla
            vista.setPantallaIcon(null);
            }
        }
    }
    
    public void procesarClickCanal2(){
        
        DefaultListModel lisFav=modelo.getListaFavs();
        int canSelecc=modelo.getCanalSeleccionado();
        ArrayList<Integer> canalesEnFavs=modelo.getCanalesEnFavoritos();
        
        if(vista.isOrdenarSelected()){//si se pulso ordenar
            
            if(modelo.isCanalSeleccionado()){//se intercambian los canales de sitio
                String textoActual=modelo.getCanal(2);
                ImageIcon iconoActual=modelo.getIconCanal(2);
                boolean visionActual=modelo.getVisionCanal(2);
                
                modelo.setCanal(2,modelo.getCanal(canSelecc),modelo.getIconCanal(canSelecc));
                modelo.setCanal(canSelecc,textoActual,iconoActual);
                modelo.setVisionCanal(2, modelo.getVisionCanal(canSelecc));
                modelo.setVisionCanal(canSelecc, visionActual);
                
                if(canalesEnFavs.contains(2)){
                canalesEnFavs.set(canalesEnFavs.indexOf(1), -2);
                }
                if(canalesEnFavs.contains(canSelecc)){
                canalesEnFavs.set(canalesEnFavs.indexOf(canSelecc), 1);
                }
                if(canalesEnFavs.contains(-2)){
                canalesEnFavs.set(canalesEnFavs.indexOf(-2),canSelecc);
                }
                
                modelo.setCanalesEnFavoritos(canalesEnFavs); //actualizamos la lista
                
                vista.refrescar();
                modelo.setIsCanalSeleccionado(false);
                vista.sinSeleccionar();
            }
            
            else{//se marca como canal seleccionado 
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(2);
            vista.remarcarCanal(2); 
            }
            
        }
        
        else if(vista.isFavoritosSelected()){//si se pulso favoritos
          
            if(lisFav.contains(modelo.getCanal(2))==false){//se añade si no lo contiene ya
            lisFav.addElement(modelo.getCanal(2));//////////////
            canalesEnFavs.add(2);
            modelo.setCanalesEnFavoritos(canalesEnFavs);
            modelo.setListaFavs(lisFav);
            }
        }
        
        else if(vista.isEditarSelected()){//si se pulso editar
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(2);
            vista.setCanalText("  Canal: "+modelo.getCanal(2));
            vista.setNombreCanalText(modelo.getCanal(2));
            vista.setActivadoSelected(modelo.getVisionCanal(2));
        }
        
        else {
            if(modelo.getVisionCanal(2)){
            vista.setPantallaIcon(modelo.getIconCanal(2)); //si no hay nada seleccionado,se muestra en pantalla
            }
            else{
            vista.setPantallaIcon(null);
            }
        }
    }
    
    public void procesarClickCanal3(){
        
        DefaultListModel lisFav=modelo.getListaFavs();
        int canSelecc=modelo.getCanalSeleccionado();
        ArrayList<Integer> canalesEnFavs=modelo.getCanalesEnFavoritos();
        
        if(vista.isOrdenarSelected()){//si se pulso ordenar
            
            if(modelo.isCanalSeleccionado()){//se intercambian los canales de sitio
                String textoActual=modelo.getCanal(3);
                ImageIcon iconoActual=modelo.getIconCanal(3);
                boolean visionActual=modelo.getVisionCanal(3);
                
                modelo.setCanal(3,modelo.getCanal(canSelecc),modelo.getIconCanal(canSelecc));
                modelo.setCanal(canSelecc,textoActual,iconoActual);
                modelo.setVisionCanal(3, modelo.getVisionCanal(canSelecc));
                modelo.setVisionCanal(canSelecc, visionActual);
                
                if(canalesEnFavs.contains(3)){
                canalesEnFavs.set(canalesEnFavs.indexOf(1), -2);
                }
                if(canalesEnFavs.contains(canSelecc)){
                canalesEnFavs.set(canalesEnFavs.indexOf(canSelecc), 1);
                }
                if(canalesEnFavs.contains(-2)){
                canalesEnFavs.set(canalesEnFavs.indexOf(-2),canSelecc);
                }
                
                modelo.setCanalesEnFavoritos(canalesEnFavs); //actualizamos la lista
                
                vista.refrescar();
                modelo.setIsCanalSeleccionado(false);
                vista.sinSeleccionar();
            }
            
            else{//se marca como canal seleccionado 
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(3);
            vista.remarcarCanal(3); 
            }
            
        }
        
        else if(vista.isFavoritosSelected()){//si se pulso favoritos
          
            if(lisFav.contains(modelo.getCanal(3))==false){//se añade si no lo contiene ya
            lisFav.addElement(modelo.getCanal(3));//////////////
            canalesEnFavs.add(3);
            modelo.setCanalesEnFavoritos(canalesEnFavs);
            modelo.setListaFavs(lisFav);
            }
        }
        
        else if(vista.isEditarSelected()){//si se pulso editar
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(3);
            vista.setCanalText("  Canal: "+modelo.getCanal(3));
            vista.setNombreCanalText(modelo.getCanal(3));
            vista.setActivadoSelected(modelo.getVisionCanal(3));
        }
        
        else {
            if(modelo.getVisionCanal(3)){
            vista.setPantallaIcon(modelo.getIconCanal(3)); //si no hay nada seleccionado,se muestra en pantalla
            }
            else{
            vista.setPantallaIcon(null);
            }
        }
    }
    
    public void procesarClickCanal4(){
        
        DefaultListModel lisFav=modelo.getListaFavs();
        int canSelecc=modelo.getCanalSeleccionado();
        ArrayList<Integer> canalesEnFavs=modelo.getCanalesEnFavoritos();
        
        if(vista.isOrdenarSelected()){//si se pulso ordenar
            
            if(modelo.isCanalSeleccionado()){//se intercambian los canales de sitio
                String textoActual=modelo.getCanal(4);
                ImageIcon iconoActual=modelo.getIconCanal(4);
                boolean visionActual=modelo.getVisionCanal(4);
                
                modelo.setCanal(4,modelo.getCanal(canSelecc),modelo.getIconCanal(canSelecc));
                modelo.setCanal(canSelecc,textoActual,iconoActual);
                modelo.setVisionCanal(4, modelo.getVisionCanal(canSelecc));
                modelo.setVisionCanal(canSelecc, visionActual);
                
                if(canalesEnFavs.contains(4)){
                canalesEnFavs.set(canalesEnFavs.indexOf(1), -2);
                }
                if(canalesEnFavs.contains(canSelecc)){
                canalesEnFavs.set(canalesEnFavs.indexOf(canSelecc), 1);
                }
                if(canalesEnFavs.contains(-2)){
                canalesEnFavs.set(canalesEnFavs.indexOf(-2),canSelecc);
                }
                
                modelo.setCanalesEnFavoritos(canalesEnFavs); //actualizamos la lista
                
                vista.refrescar();
                modelo.setIsCanalSeleccionado(false);
                vista.sinSeleccionar();
            }
            
            else{//se marca como canal seleccionado 
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(4);
            vista.remarcarCanal(4); 
            }
            
        }
        
        else if(vista.isFavoritosSelected()){//si se pulso favoritos
          
            if(lisFav.contains(modelo.getCanal(4))==false){//se añade si no lo contiene ya
            lisFav.addElement(modelo.getCanal(4));//////////////
            canalesEnFavs.add(4);
            modelo.setCanalesEnFavoritos(canalesEnFavs);
            modelo.setListaFavs(lisFav);
            }
        }
        
        else if(vista.isEditarSelected()){//si se pulso editar
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(4);
            vista.setCanalText("  Canal: "+modelo.getCanal(4));
            vista.setNombreCanalText(modelo.getCanal(4));
            vista.setActivadoSelected(modelo.getVisionCanal(4));
        }
        
        else {
            if(modelo.getVisionCanal(4)){
            vista.setPantallaIcon(modelo.getIconCanal(4)); //si no hay nada seleccionado,se muestra en pantalla
            }
            else{
            vista.setPantallaIcon(null);
            }
        }
    }
    
    public void procesarClickCanal5(){
        
        DefaultListModel lisFav=modelo.getListaFavs();
        int canSelecc=modelo.getCanalSeleccionado();
        ArrayList<Integer> canalesEnFavs=modelo.getCanalesEnFavoritos();
        
        if(vista.isOrdenarSelected()){//si se pulso ordenar
            
            if(modelo.isCanalSeleccionado()){//se intercambian los canales de sitio
                String textoActual=modelo.getCanal(5);
                ImageIcon iconoActual=modelo.getIconCanal(5);
                boolean visionActual=modelo.getVisionCanal(5);
                
                modelo.setCanal(5,modelo.getCanal(canSelecc),modelo.getIconCanal(canSelecc));
                modelo.setCanal(canSelecc,textoActual,iconoActual);
                modelo.setVisionCanal(5, modelo.getVisionCanal(canSelecc));
                modelo.setVisionCanal(canSelecc, visionActual);
                
                if(canalesEnFavs.contains(5)){
                canalesEnFavs.set(canalesEnFavs.indexOf(1), -2);
                }
                if(canalesEnFavs.contains(canSelecc)){
                canalesEnFavs.set(canalesEnFavs.indexOf(canSelecc), 1);
                }
                if(canalesEnFavs.contains(-2)){
                canalesEnFavs.set(canalesEnFavs.indexOf(-2),canSelecc);
                }
                
                modelo.setCanalesEnFavoritos(canalesEnFavs); //actualizamos la lista
                
                vista.refrescar();
                modelo.setIsCanalSeleccionado(false);
                vista.sinSeleccionar();
            }
            
            else{//se marca como canal seleccionado 
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(5);
            vista.remarcarCanal(5); 
            }
            
        }
        
        else if(vista.isFavoritosSelected()){//si se pulso favoritos
          
            if(lisFav.contains(modelo.getCanal(5))==false){//se añade si no lo contiene ya
            lisFav.addElement(modelo.getCanal(5));//////////////
            canalesEnFavs.add(5);
            modelo.setCanalesEnFavoritos(canalesEnFavs);
            modelo.setListaFavs(lisFav);
            }
        }
        
        else if(vista.isEditarSelected()){//si se pulso editar
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(5);
            vista.setCanalText("  Canal: "+modelo.getCanal(5));
            vista.setNombreCanalText(modelo.getCanal(5));
            vista.setActivadoSelected(modelo.getVisionCanal(5));
        }
        
        else {
            if(modelo.getVisionCanal(5)){
            vista.setPantallaIcon(modelo.getIconCanal(5)); //si no hay nada seleccionado,se muestra en pantalla
            }
            else{
            vista.setPantallaIcon(null);
            }
        }
    }
    
    public void procesarClickCanal6(){
        
        DefaultListModel lisFav=modelo.getListaFavs();
        int canSelecc=modelo.getCanalSeleccionado();
        ArrayList<Integer> canalesEnFavs=modelo.getCanalesEnFavoritos();
        
        if(vista.isOrdenarSelected()){//si se pulso ordenar
            
            if(modelo.isCanalSeleccionado()){//se intercambian los canales de sitio
                String textoActual=modelo.getCanal(6);
                ImageIcon iconoActual=modelo.getIconCanal(6);
                boolean visionActual=modelo.getVisionCanal(6);
                
                modelo.setCanal(6,modelo.getCanal(canSelecc),modelo.getIconCanal(canSelecc));
                modelo.setCanal(canSelecc,textoActual,iconoActual);
                modelo.setVisionCanal(6, modelo.getVisionCanal(canSelecc));
                modelo.setVisionCanal(canSelecc, visionActual);
                
                if(canalesEnFavs.contains(6)){
                canalesEnFavs.set(canalesEnFavs.indexOf(1), -2);
                }
                if(canalesEnFavs.contains(canSelecc)){
                canalesEnFavs.set(canalesEnFavs.indexOf(canSelecc), 1);
                }
                if(canalesEnFavs.contains(-2)){
                canalesEnFavs.set(canalesEnFavs.indexOf(-2),canSelecc);
                }
                
                modelo.setCanalesEnFavoritos(canalesEnFavs); //actualizamos la lista
                
                vista.refrescar();
                modelo.setIsCanalSeleccionado(false);
                vista.sinSeleccionar();
            }
            
            else{//se marca como canal seleccionado 
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(6);
            vista.remarcarCanal(6); 
            }
            
        }
        
        else if(vista.isFavoritosSelected()){//si se pulso favoritos
          
            if(lisFav.contains(modelo.getCanal(6))==false){//se añade si no lo contiene ya
            lisFav.addElement(modelo.getCanal(6));//////////////
            canalesEnFavs.add(6);
            modelo.setCanalesEnFavoritos(canalesEnFavs);
            modelo.setListaFavs(lisFav);
            }
        }
        
        else if(vista.isEditarSelected()){//si se pulso editar
            modelo.setIsCanalSeleccionado(true);
            modelo.setCanalSeleccionado(6);
            vista.setCanalText("  Canal: "+modelo.getCanal(6));
            vista.setNombreCanalText(modelo.getCanal(6));
            vista.setActivadoSelected(modelo.getVisionCanal(6));
        }
        
        else {
            if(modelo.getVisionCanal(6)){
            vista.setPantallaIcon(modelo.getIconCanal(6)); //si no hay nada seleccionado,se muestra en pantalla
            }
            else{
            vista.setPantallaIcon(null);
            }
        }
    }
                    /////////////PULSAR EN OTRAS TECLAS  ///////////////////
    
    public void procesaClickBorrar(){
        
        if(vista.isFavoritosSelected()){
            
            DefaultListModel listaF=modelo.getListaFavs();
            ArrayList<Integer> listaN=modelo.getCanalesEnFavoritos();
            
            if(vista.getListaFavoritosSelectedIndex()!=-1){//si existe un elemento seleccionado en la lista, se borra
                listaF.remove(vista.getListaFavoritosSelectedIndex());
                modelo.setListaFavs(listaF); //actualizamos las listas 
                listaN.remove(vista.getListaFavoritosSelectedIndex());
                modelo.setCanalesEnFavoritos(listaN); //actualizamos las listas
            }
        }
    }
    
    public void procesaClickOrdenar(){
        
        vista.sinSeleccionar();
        if(vista.isOrdenarSelected()){//SE ACTIVA ORDENAR
        modelo.setIsCanalSeleccionado(false);
        vista.setFavoritosSelected(false); //desactivar los otros botones cuando se pulsa uno
        vista.setEditarSelected(false);
        vista.setListaFavoritosEnabled(false);
        vista.setActivadoEnabled(false);
        vista.setNombreCanalEnabled(false);
        }
        
    }
    
    public void procesaClickFavoritos(){
 
        vista.sinSeleccionar();
        if(vista.isFavoritosSelected()){//SE ACTIVA FAVORITOS
        modelo.setIsCanalSeleccionado(false);
        vista.setOrdenarSelected(false); //desactivar los otros botones cuando se pulsa uno
        vista.setEditarSelected(false);
        vista.setListaFavoritosEnabled(true);
        vista.setActivadoEnabled(false);
        vista.setNombreCanalEnabled(false);
        }
        else{//SE DESACTIVA FAVORITOS
            vista.setListaFavoritosEnabled(false);
        }
    }
    
    public void procesaClickEditar(){
        vista.sinSeleccionar();
        if(vista.isEditarSelected()){//SE ACTIVA EDITAR
        modelo.setIsCanalSeleccionado(false);
        vista.setOrdenarSelected(false); //desactivar los otros botones cuando se pulsa uno
        vista.setFavoritosSelected(false);
        vista.setListaFavoritosEnabled(false);
        vista.setActivadoEnabled(true);
        vista.setNombreCanalEnabled(true);
        }
        else{//SE DESACTIVA EDITAR
            vista.setActivadoEnabled(false);
            vista.setNombreCanalEnabled(false);
        }
    }
    
    public void procesaClickActivado(){
        if(vista.isActivadoSelected()){//SE ACTIVA UN CANAL
            modelo.setVisionCanal(modelo.getCanalSeleccionado(), true);
        }
        else{//SE DESACTIVA UN CANAL
            modelo.setVisionCanal(modelo.getCanalSeleccionado(),false);
        }
    }
    
    public void procesaNombreCanalKeyRealeased(){
        if(modelo.isCanalSeleccionado()){
            
            modelo.setCanal(modelo.getCanalSeleccionado(),vista.getNombreCanalText(),modelo.getIconCanal(modelo.getCanalSeleccionado()));
            vista.refrescar();
            vista.setCanalText("  Canal: "+modelo.getCanal(modelo.getCanalSeleccionado()));
            DefaultListModel m=modelo.getListaFavs();
        
            if(modelo.getCanalesEnFavoritos().indexOf(modelo.getCanalSeleccionado())!=-1){//si esta en favoritos
                m.set(modelo.getCanalesEnFavoritos().indexOf(modelo.getCanalSeleccionado()),modelo.getCanal(modelo.getCanalSeleccionado()));
                modelo.setListaFavs(m);
            }
        }
    }
    
    
}