
package Modelo;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
/**
 *
 * @author laucami
 * @author roggonz
 */
public class Modelo {
    
     //ICONOS DE LOS CANALES
    
    private ImageIcon iconCanal1;
    private ImageIcon iconCanal2;
    private ImageIcon iconCanal3;
    private ImageIcon iconCanal4;
    private ImageIcon iconCanal5;
    private ImageIcon iconCanal6;
    
    //NOMBRES DE LOS CANALES 
    
    private String canal1="La 1";
    private String canal2="La 2";
    private String canal3="Antena 3";
    private String canal4="Cuatro";
    private String canal5="Telecinco";
    private String canal6="La Sexta";
    
    //VISION DE LOS CANALES
    
    private boolean visionCanal1;
    private boolean visionCanal2;
    private boolean visionCanal3;
    private boolean visionCanal4;
    private boolean visionCanal5;
    private boolean visionCanal6;
    
    //OTRAS VARIABLES
    
    private boolean isCanalSeleccionado;
    private int canalSeleccionado;
    private DefaultListModel listaFavs;
    private ArrayList<Integer> canalesEnFavoritos;
    
    /**
     * Constructor de Modelo
     */
    public Modelo(){
        
    iconCanal1=new ImageIcon("src/main/java/Imagenes/La1.png");
    iconCanal2=new ImageIcon("src/main/java/Imagenes/La2.png");
    iconCanal3=new ImageIcon("src/main/java/Imagenes/antena3.png");
    iconCanal4=new ImageIcon("src/main/java/Imagenes/Cuatro.png");
    iconCanal5=new ImageIcon("src/main/java/Imagenes/Telecinco.png");
    iconCanal6=new ImageIcon("src/main/java/Imagenes/LaSextaa.png");
    
    canal1="La 1";
    canal2="La 2";
    canal3="Antena 3";
    canal4="Cuatro";
    canal5="Telecinco";
    canal6="La Sexta";
    
    visionCanal1=true;
    visionCanal2=true;
    visionCanal3=true;
    visionCanal4=true;
    visionCanal5=true;
    visionCanal6=true;
    
    isCanalSeleccionado=false;
    listaFavs=new DefaultListModel();
    canalesEnFavoritos=new ArrayList<Integer>();
    
    }
    
    public String getCanal(int numCanal){
        
        if(numCanal==1){return canal1;}
        else if(numCanal==2){return canal2;}
        else if(numCanal==3){return canal3;}
        else if(numCanal==4){return canal4;}
        else if(numCanal==5){return canal5;}
        else if(numCanal==6){return canal6;}
        else{//error
            return "error";}   
    }
    
    public ImageIcon getIconCanal(int numCanal){
        
        if(numCanal==1){return iconCanal1;}
        else if(numCanal==2){return iconCanal2;}
        else if(numCanal==3){return iconCanal3;}
        else if(numCanal==4){return iconCanal4;}
        else if(numCanal==5){return iconCanal5;}
        else if(numCanal==6){return iconCanal6;}
        else{return null;}  
    }
    
    public void setCanal(int numCanal,String textCanal,ImageIcon iconoCanal){
        if(numCanal==1){
            canal1=textCanal;
            iconCanal1=iconoCanal;
        }
        else if(numCanal==2){
            canal2=textCanal;
            iconCanal2=iconoCanal;
        }
        else if(numCanal==3){
            canal3=textCanal;
            iconCanal3=iconoCanal;
        }
        else if(numCanal==4){
            canal4=textCanal;
            iconCanal4=iconoCanal;
        }
        else if(numCanal==5){
            canal5=textCanal;
            iconCanal5=iconoCanal;
        }
        else if(numCanal==6){
            canal6=textCanal;
            iconCanal6=iconoCanal;
        }
    }
    
    public boolean getVisionCanal(int numCanal){
        
        if(numCanal==1){if(visionCanal1){return true;}}
        else if(numCanal==2){if(visionCanal2){return true;}}
        else if(numCanal==3){if(visionCanal3){return true;}}
        else if(numCanal==4){if(visionCanal4){return true;}}
        else if(numCanal==5){if(visionCanal5){return true;}}
        else if(numCanal==6){if(visionCanal6){return true;}}
        return false;
        
    }
    
    public void setVisionCanal(int numCanal,boolean vision){
        
        if(numCanal==1){visionCanal1=vision;}
        else if(numCanal==2){visionCanal2=vision;}
        else if(numCanal==3){visionCanal3=vision;}
        else if(numCanal==4){visionCanal4=vision;}
        else if(numCanal==5){visionCanal5=vision;}
        else if(numCanal==6){visionCanal6=vision;}
    }
    
    public boolean isCanalSeleccionado() {
        return isCanalSeleccionado;
    }

    public void setIsCanalSeleccionado(boolean isCanalSeleccionado) {
        this.isCanalSeleccionado = isCanalSeleccionado;
    }

    public int getCanalSeleccionado() {
        return canalSeleccionado;
    }

    public void setCanalSeleccionado(int canalSeleccionado) {
        this.canalSeleccionado = canalSeleccionado;
    }

    public DefaultListModel getListaFavs() {
        return listaFavs;
    }

    public void setListaFavs(DefaultListModel listaFavs) {
        this.listaFavs = listaFavs;
    }

    public ArrayList<Integer> getCanalesEnFavoritos() {
        return canalesEnFavoritos;
    }

    public void setCanalesEnFavoritos(ArrayList<Integer> canalesEnFavoritos) {
        this.canalesEnFavoritos = canalesEnFavoritos;
    }
    
}
